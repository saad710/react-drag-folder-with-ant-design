import logo from './logo.svg';
import './App.css';
import FolderDrag from './FolderDrag';


function App() {
  return (
    <div className="App">
     <FolderDrag/>
    </div>
  );
}

export default App;
